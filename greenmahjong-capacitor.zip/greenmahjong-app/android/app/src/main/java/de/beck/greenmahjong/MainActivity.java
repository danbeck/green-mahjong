package de.beck.greenmahjong;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
